﻿using System.Drawing;
using AmicitiaLibrary.Graphics.TMX;
using System.Text.Encodings;
using System.Text;

namespace TmxToPng
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                Console.WriteLine("Usage: Drag a .tmx file onto the executable to convert to a .png");
                return;
            }

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            foreach (string arg in args)
            {
                var tmx = TmxFile.Load(args[0]);

                ConvertAndExportTmx(tmx, Path.ChangeExtension(arg, ".png"));
            }

            
        }

        static void ConvertAndExportTmx(TmxFile tmxFile, string output_path)
        {
            var bitmap = tmxFile.GetBitmap();

            bitmap.Save(output_path);
            bitmap.Dispose();
        }
    }
}